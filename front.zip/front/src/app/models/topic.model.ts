export interface Topic {
  id: number;
  name: string;
}
