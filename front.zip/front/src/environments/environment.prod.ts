export const environment = {
  production: true,
  apiUrl: 'https://api.mdd.example.com/api',
};
